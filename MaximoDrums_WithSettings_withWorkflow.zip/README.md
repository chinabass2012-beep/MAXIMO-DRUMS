# Maximo Drums (with Settings UI)
Project prepared for GitHub Actions build.

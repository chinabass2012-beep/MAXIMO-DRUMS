package com.maximodrums;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // simple UI: button to open settings
        Button btn = new Button(this);
        btn.setText("Abrir Configurações (Sensibilidade / Mapas / Banks)");
        btn.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        setContentView(btn);
    }
}

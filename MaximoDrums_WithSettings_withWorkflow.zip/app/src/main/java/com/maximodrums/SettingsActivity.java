package com.maximodrums;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        prefs = getSharedPreferences("maximo_prefs", MODE_PRIVATE);

        SeekBar sbSensitivity = findViewById(R.id.sbSensitivity);
        TextView tvVal = findViewById(R.id.tvSensitivityVal);
        int s = prefs.getInt("sensitivity", 50);
        sbSensitivity.setProgress(s);
        tvVal.setText(String.valueOf(s));
        sbSensitivity.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                tvVal.setText(String.valueOf(progress));
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                prefs.edit().putInt("sensitivity", seekBar.getProgress()).apply();
            }
        });

        // Pad mapping editor (simple: pad number and MIDI note)
        EditText etPad = findViewById(R.id.etPadNumber);
        EditText etNote = findViewById(R.id.etPadNote);
        Button btnSavePad = findViewById(R.id.btnSavePad);
        btnSavePad.setOnClickListener(v -> {
            String pad = etPad.getText().toString();
            String note = etNote.getText().toString();
            if (!pad.isEmpty() && !note.isEmpty()) {
                prefs.edit().putInt("pad_" + pad, Integer.parseInt(note)).apply();
            }
        });

        // Bank selector
        Spinner spBanks = findViewById(R.id.spBanks);
        String[] banks = new String[]{"Rock Acústico","Metal","Funk","Jazz","Eletrônico","Lo-Fi","Latina","Brasileira","Étnica"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, banks);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spBanks.setAdapter(adapter);
        spBanks.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, android.view.View view, int position, long id) {
                prefs.edit().putString("current_bank", banks[position]).apply();
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
        });

        // Restore saved bank
        String cur = prefs.getString("current_bank", "Rock Acústico");
        int idx = 0;
        for (int i=0;i<banks.length;i++) if (banks[i].equals(cur)) idx = i;
        spBanks.setSelection(idx);
    }
}
